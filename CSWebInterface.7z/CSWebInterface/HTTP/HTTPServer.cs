﻿using System;
using System.Net;
using System.Threading;
using System.Collections;
using CSBase.Tools;
namespace CSWebInterface.HTTP
{
    static class HTTPServer
    {
        public static int Requests { get; private set; }
        public static int Commands { get; private set; }
        private static HttpListener _listener;
        private static Thread _listenerThread;
        private static CSBase.Communication.Connector _con;
        public static void StartServer(int aPort , CSBase.Communication.Connector aCon)
        {
            Logger.Log("Init Webserver -> Port:" + aPort, Logger.LogLevel.DBG);
            _listener = new HttpListener();
            _listener.Prefixes.Add(@"http://*:" + aPort + @"/");
            _listener.Start();
            _listenerThread = new Thread(HandleRequests) {Name = "HTTPListener"};
            _listenerThread.Start();
            _con = aCon;
            Sites.WinampMain.Init(aCon,"winamp");
            Logger.Log("Webserver started", Logger.LogLevel.DBG);
        }
        private static void HandleRequests()
        {
            while (_listener.IsListening)
            {
                ThreadPool.QueueUserWorkItem(ClientRequest, _listener.GetContext());
                Thread.Sleep(1);
            }
        }

        private static void ClientRequest(object o)
        {
            Requests++;
            var context = o as HttpListenerContext;
            if (Thread.CurrentThread.Name == null) Thread.CurrentThread.Name = "HTTPResponse<" + context.Request.RemoteEndPoint + ">";
            Logger.Log("New HTTP Request -> Uri:" + context.Request.RawUrl,Logger.LogLevel.DBG);
            string site="", command="",  responsString="";
            PharseUri(context.Request.RawUrl.ToLower(), out site, out command);
            Logger.Log("HTTP Request -> Site:" + site + " Command:" + command, Logger.LogLevel.DBG);

            if (String.IsNullOrEmpty(command))
            {
                switch (site)
                {
                    case "winamp":
                        {
                            responsString = Sites.WinampMain.SourceCode;
                        }
                        break;
                    default:
                        {
                            responsString = "Unknow Site";
                        }
                        break;
                }
                Respond(context, responsString);
            }
            else
            {
                Commands++;
                switch (site)
                {
                    case "winamp":
                        {
                            Sites.WinampMain.HandleCommand(command);
                            Navigate(context, Sites.WinampMain.BaseUri);
                        }
                        break;
                    default:
                        {
                            responsString = "Unknow Site";
                        }
                        break;
                }
            }
        }
        private static void Navigate(HttpListenerContext aClient, string aUri)
        {
            string responsString = "<script language=\"javascript\"> window.location.href = \"" + aUri + "\"</script>";
            Respond(aClient, responsString);
        }
        private static void PharseUri(string aUri, out string aSite, out string aCom)
        {
            string tmpSite="", tmpCom="";
            aUri = aUri.Substring(1); // Remove / at begin of Uri
            if (aUri.Contains("?"))
            {
                try
                {
                    tmpSite = aUri.Substring(0, aUri.IndexOf('?'));
                }
                catch (Exception ex)
                {
                    Logger.Log("Can't pharse Site -> Uri:" + aUri + " Excetion:" + ex.ToString(), Logger.LogLevel.ERR);
                }
                try
                {
                    tmpCom = aUri.Substring(aUri.IndexOf('?')+1);
                }
                catch (Exception ex)
                {
                    Logger.Log("Can't pharse Command -> Uri:" + aUri, Logger.LogLevel.WRN);
                }  
            }
            else
            {
                tmpSite = aUri;
                tmpCom = "";
            }
            
            aSite = tmpSite;
            aCom = tmpCom;
        }
        private static void Respond(HttpListenerContext aClient, string aSource)
        {
            Logger.Log("Send data to Client -> Datalen:" + aSource.Length,Logger.LogLevel.DBG);
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(aSource);
            aClient.Response.ContentLength64 = buffer.Length;
            System.IO.Stream output = aClient.Response.OutputStream;
            output.Write(buffer, 0, buffer.Length);
            output.Flush();
            output.Dispose();
            Logger.Log("Send data to Client successful ", Logger.LogLevel.DBG);
        }
    }
}
