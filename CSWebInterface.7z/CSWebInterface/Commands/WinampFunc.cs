﻿using System.Reflection;
using CSBase;
using CSBase.Communication;
using CSBase.Tools;

namespace CSWebInterface.Commands
{
    public class WinampFunc
    {
        internal static void PassCommand(TGM aTGM)
        {
            Global.InvokeStringMethod(MethodBase.GetCurrentMethod().DeclaringType.FullName, ((CSBase.Commands.WinampFunc.Commands)aTGM.ComID).ToString(), aTGM);
        }
        private static void GetPlaylist(TGM aTGM)
        {
            Logger.Log("Rcv Playlist -> " + aTGM, Logger.LogLevel.DBG);
            CSWebInterface.HTTP.Sites.WinampMain.UpdatePlaylist(aTGM.Data);
        }
    }

}
